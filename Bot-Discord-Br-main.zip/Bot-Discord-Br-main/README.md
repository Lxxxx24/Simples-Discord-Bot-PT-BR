# Discord Bot JS
Um simples bot para discord para quem esta querendo começar a programar em JS 
